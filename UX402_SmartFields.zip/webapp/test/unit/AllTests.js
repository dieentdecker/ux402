sap.ui.define([
	"student00/com/sap/training/UX402_SmartFields/test/unit/controller/Main.controller"
], function () {
	"use strict";
});