/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"student00/com/sap/training/UX402_SmartFields/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});