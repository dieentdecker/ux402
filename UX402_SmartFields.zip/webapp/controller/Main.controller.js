sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("student00.com.sap.training.UX402_SmartFields.controller.Main", {
		onInit: function () {
			var sPath = "/FlightSet(Carrid='AA',Connid='0017',Fldate=datetime'2019-08-16T00%3A00%3A00')";
			this.getView().bindElement(sPath);
		}
	});
});