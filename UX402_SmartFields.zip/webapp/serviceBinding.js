function initModel() {
	var sUrl = "/sap/opu/odata/sap/ZUX402_FLIGHT_00_SRV/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}