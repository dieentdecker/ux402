sap.ui.define([
	"com/sap/training/ux402/opa/UX402_OPA/test/unit/controller/Main.controller"
], function () {
	"use strict";
});