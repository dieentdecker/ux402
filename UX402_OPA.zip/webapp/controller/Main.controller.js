sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("com.sap.training.ux402.opa.UX402_OPA.controller.Main", {
		onInit: function () {

		},
		
		onPress: function(oEvent){
			MessageBox.show("Button pressed");
		}
	});
});