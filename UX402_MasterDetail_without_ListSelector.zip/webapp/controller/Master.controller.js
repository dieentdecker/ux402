sap.ui.define([
	"com/sap/training/ux402/masterdetail/UX402_MasterDetailExercise/controller/BaseController",
	"sap/ui/Device"
], function (Controller, Device) {
	"use strict";

	return Controller.extend("com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.controller.Master", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.view.Master
		 */
		onInit: function () {
			this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
		},

		_onMasterMatched: function () {
			this.getOwnerComponent().myList = this.getView().byId("list");

			this.getOwnerComponent().myList.getBinding("items").attachEventOnce("dataReceived", function () {
				
				
				if (Device.system.phone) {
					return;
				}
				
				var sObjectId = this.getOwnerComponent().myList.getItems()[0].getBindingContext().getProperty("AirLineID");
				this._navigateToCarrierDetails(sObjectId, true);
			}.bind(this));
		},

		_navigateToCarrierDetails: function (sCarrierId, bReplace) {
			this.getRouter().navTo("detail", {
				objectId: sCarrierId
			}, bReplace);
		},

		_showDetail: function (oItem) {
			var bReplace = !Device.system.phone;

			var sCarrId = oItem.getBindingContext().getProperty("AirLineID");
			this._navigateToCarrierDetails(sCarrId, bReplace);
		},

		onSelect: function (oEvent) {
			this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
		},

		onBypassed: function () {
			this.getOwnerComponent().myList.removeSelections();
		}
	});

});