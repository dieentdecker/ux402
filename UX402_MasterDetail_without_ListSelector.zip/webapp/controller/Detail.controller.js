sap.ui.define([
	"com/sap/training/ux402/masterdetail/UX402_MasterDetailExercise/controller/BaseController",
	"sap/ui/Device"
], function (Controller, Device) {
	"use strict";

	return Controller.extend("com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.controller.Detail", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.view.Detail
		 */
		onInit: function () {
			this.getRouter().getRoute("detail").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function (oEvent) {
			var sObject = "/CarrierCollection('" + oEvent.getParameter("arguments").objectId + "')";
			this._bindView(sObject);
		},

		_oBindingChange: function () {
			var oView = this.getView();

			var oElementBinding = oView.getElementBinding();
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				this.getOwnerComponent().myList.removeSelections();
				return;
			}

			var oSelectedItem = this.getOwnerComponent().myList.getSelectedItem();
			var sPath = oElementBinding.getPath();
			if (oSelectedItem && oSelectedItem.getBindingContext().getPath() === sPath) {
				this.getOwnerComponent().myList.setSelectedItem(oSelectedItem);
			} else {
				this.getOwnerComponent().myList.getItems().some(function (oItem) {
					if (oItem.getBindingContext() && oItem.getBindingContext().getPath() === sPath) {
						this.getOwnerComponent().myList.setSelectedItem(oItem);
						return true;
					}
				}.bind(this));
			}

		},

		_bindView: function (sObjectPath) {
			var oView = this.getView();

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._oBindingChange.bind(this),
					dataRequested: function () {
						oView.setBusy(true);
					},
					dataRecevied: function () {
						oView.setBusy(false);
					}
				}
			});
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.view.Detail
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.view.Detail
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.view.Detail
		 */
		//	onExit: function() {
		//
		//	}

	});

});