jQuery.sap.declare("com.sap.training.ux402.fullscreen.UX402_ExtendableWriteSupport00.ZUX402_EXTAPP29Extension.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "com.sap.training.ux402.fullscreen.UX402_ExtendableWriteSupport00",
	// Use the below URL to run the extended application when SAP-delivered application is deployed on SAPUI5 ABAP Repository
	url: "/sap/bc/ui5_ui5/sap/ZUX402_EXTAPP29"
		// we use a URL relative to our own component
		// extension application is deployed with customer namespace
});

this.com.sap.training.ux402.fullscreen.UX402_ExtendableWriteSupport00.Component.extend(
	"com.sap.training.ux402.fullscreen.UX402_ExtendableWriteSupport00.ZUX402_EXTAPP29Extension.Component", {
		metadata: {
			manifest: "json"
		}
	});