sap.ui.define(["sap/ui/core/mvc/Controller", "sap/m/MessageBox"], function (e, MessageBox) {
	"use strict";
	return sap.ui.controller(
		"com.sap.training.ux402.fullscreen.UX402_ExtendableWriteSupport00.ZUX402_EXTAPP29Extension.controller.CarrierCustom", {
			//    onInit: function () {
			//    },
			onPress: function (e) {
				MessageBox.show("Not allowed");
			}
		});
});