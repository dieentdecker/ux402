sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function (AppComponent) {
	return AppComponent.extend("com.sap.training.ux402.lr.ux402_listreportwithserverannotations.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});