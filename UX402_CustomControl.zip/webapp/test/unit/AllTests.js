sap.ui.define([
	"com/sap/training/ux402/fullscreen/UX402_FullScreenExercise/test/unit/controller/Main.controller"
], function () {
	"use strict";
});