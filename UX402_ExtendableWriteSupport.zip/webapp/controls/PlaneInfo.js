sap.ui.define([
	"sap/ui/core/Control",
	"com/sap/training/ux402/fullscreen/UX402_ExtendableWriteSupport00/controls/PlaneInfoRenderer"
], function (Control, PlaneInfoRenderer) {
	"use strict";

	return Control.extend("com.sap.training.ux402.fullscreen.UX402_ExtendableWriteSupport00.controls.PlaneInfo", {
		metadata: {
			properties: {
				"seatsMax": {
					type: "string"
				},
				"seatsOcc": {
					type: "string"
				},
				"planeType": {
					type: "string"
				}
			}
		},
		renderer: PlaneInfoRenderer
	});
});