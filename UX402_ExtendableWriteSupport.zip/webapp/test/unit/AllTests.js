sap.ui.define([
	"com/sap/training/ux402/fullscreen/UX402_ExtendableWriteSupport00/test/unit/controller/Main.controller"
], function () {
	"use strict";
});