sap.ui.define([
	"com/sap/training/ux402/masterdetail/UX402_MasterDetailExercise/test/unit/controller/Main.controller"
], function () {
	"use strict";
});