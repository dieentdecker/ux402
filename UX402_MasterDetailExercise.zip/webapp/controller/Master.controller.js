sap.ui.define([
	"com/sap/training/ux402/masterdetail/UX402_MasterDetailExercise/controller/BaseController",
	"sap/ui/Device"
], function (Controller, Device) {
	"use strict";

	return Controller.extend("com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.controller.Master", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.view.Master
		 */
		onInit: function () {
			var oList = this.byId("list");
			this._oList = oList;
			this.getListSelector().setBoundMasterList(oList);
			this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
		},
		
		_onMasterMatched: function(){
			this.getListSelector().oWhenListLoadingIsDone.then(
				function(oParams){
					if(oParams.list.getMode() === "None"){
						return;
					}
					
					var sObjectId = oParams.firstListitem.getBindingContext().getProperty("AriLineID");
					this._navigateToCarrierDetails(sObjectId, true);
				}.bind(this));
		},
		
		_navigateToCarrierDetails: function(sCarrierId, bReplace){
			this.getRouter().navTo("detail", {
				objectId: sCarrierId
			}, bReplace);
		},
		
		_showDetail: function(oItem){
			var bReplace = !Device.system.phone;
			
			var sCarrId = oItem.getBindingContext().getProperty("AirLineID");
			this._navigateToCarrierDetails(sCarrId, bReplace);
		},
		
		onSelect: function(oEvent){
			this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
		},
		
		onBypassed: function(){
			this._oList.removeSelections(true);
		}
	});

});