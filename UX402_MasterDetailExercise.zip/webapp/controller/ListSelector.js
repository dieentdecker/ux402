sap.ui.define([
	"sap/ui/base/Object"
], function (BaseObject) {

	return BaseObject.extend("com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.controller.ListSelector", {

		constructor: function () {
			this._oWhenListHasBeenSet = new Promise(function (fnResolveListHasBeenSet) {
				this._fnResolveListHasBeenSet = fnResolveListHasBeenSet;
			}.bind(this));

			this.oWhenListLoadingIsDone = new Promise(function (fnResolve, fnReject) {
				this._oWhenListHasBeenSet.then(function (oList) {
					oList.getBinding("items").attachEventOnce("dataReceived",
						function (oData) {
							if (!oData.getParameter("data")) {
								fnReject({
									list: oList,
									error: true
								});
							}
							
							var oFirstListItem = oList.getItems()[0];
							if(oFirstListItem){
								fnResolve({
									list: oList,
									firstListItem: oFirstListItem
								});
							}else{
								fnReject({
									list: oList,
									error: false
								});
							}
						}.bind(this ));
				}.bind(this));
			}.bind(this ));
		},
		
		setBoundMasterList: function(oList){
			this._oList = oList;
			this._fnResolveListHasBeenSet(oList);
		},
		
		clearMasterListSelection: function(){
			this._oWhenListHasBeenSet.then(function(){
				this.oList.removeSelections(true);
			});
		},
		
		selectAListItem: function(sBindingPath){
			this.oWhenListLoadingIsDone.then(function(){
				var oList = this._oList,
					oSelectedItem;
				
				if(oList.getMode() === "None"){
					return;
				}else{
					oSelectedItem = oList.getSelectedItem();
					
					if(oSelectedItem && oSelectedItem.getBindingContext().getPath() === sBindingPath){
						return;
					}
					
					oList.getItems().some(function(oItem){
						if(oItem.getBindingContext() && oItem.getBindingContext().getPath() === sBindingPath){
							return true;
						}
					}.bind(this));
				}
			});
		}
	});
});