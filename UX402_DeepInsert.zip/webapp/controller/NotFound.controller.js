sap.ui.define([
		"com/sap/gdh/example/deepinsert/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("com.sap.gdh.example.deepinsert.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);