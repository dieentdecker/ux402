sap.ui.define([
	"com/sap/training/ux402/qunit/UX402_QUnit/test/unit/controller/Main.controller"
], function () {
	"use strict";
});