/*global QUnit*/

sap.ui.define([
	"com/sap/training/ux402/qunit/UX402_QUnit/controller/Main.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Main Controller");

	QUnit.test("I should test the Main controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});
	
	QUnit.test("Test the pretty date implementation", function(assert){
		var oAppController  = new Controller();
		var now = "2008/01/28 22:25:00";
		
		assert.equal(oAppController.prettyDate(now, "2008/01/28 22:25:00"), " Yesterday");
	});

});