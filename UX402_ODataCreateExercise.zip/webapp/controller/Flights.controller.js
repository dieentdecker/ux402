sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function (Controller, History, MessageToast, MessageBox) {
	"use strict";

	return Controller.extend("com.sap.training.ux402.fullscreen.UX402_FullScreenExercise.controller.Flights", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.training.ux402.fullscreen.UX402_FullScreenExercise.view.Flights
		 */
		onInit: function () {
			this.getOwnerComponent().getRouter().getRoute("flights").attachMatched(this._onObjectMatched, this);
		},
		
		_onObjectMatched: function(oEvent){
			var oArgs = oEvent.getParameter("arguments");
			this._sCarrier = oArgs.carrierId;
			
			var oView = this.getView();
			
			this.getView().bindElement({
				path: "/CarrierCollection('" + this._sCarrier + "')",
				events: {
					dataRequested: function(){
						oView.setBusy(true);
					},
					
					dataRecevied: function(){
						oView.setBusy(false);
					}
				}
			});
		},
		
		onNavBack: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.navTo("overview", {}, true);
			}
		},
		
		onHover: function(oEvent){
			var sText = this.getOwnerComponent().getModel("i18n").getProperty("msgSeatsAv");
			
			MessageToast.show(oEvent.getSource().getHoverText() + " " + sText, {durations: 1000});
		},
		
		onHoverPress: function(oEvent){
			var sCarrId = oEvent.getSource().data("id");
			var oFldate = oEvent.getSource().data("date");
			var sConnId = oEvent.getSource().data("connid");
			
			MessageBox.confirm("Are you sure you want to book this flight", function(oAction){
				if(oAction === MessageBox.Action.OK){
					var oEntry = {
						AirLineID: sCarrId,
						FlightConnectionID: sConnId,
						FlightDate: oFldate,
						BookingID: "333",
						CustomerID: "00003406",
						PassengerName: "John Doe",
						TravelAgencyID: "00000114"
					};
					
					var oModel = this.getView().getModel();
					oModel.create("/BookingCollection", oEntry, {
						success: this.successCallback.bind(this),
						error: this.errorCallback.bind(this)
					});
				}
			}.bind(this));
		},
		
		successCallback: function(oData, oResponse){
			MessageBox.alert("Flight booked. Booking reference nubmer is: " + oData.BookingID);
		},
		
		errorCallback: function(oError){
			if(oError){
				if(oError.responseText){
					var oErrorMessage = JSON.parse(oError.responseText);
					MessageBox.alert("Flight was not booked due to: " + oErrorMessage.error.message.value    );
				}
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.sap.training.ux402.fullscreen.UX402_FullScreenExercise.view.Flights
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.sap.training.ux402.fullscreen.UX402_FullScreenExercise.view.Flights
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.sap.training.ux402.fullscreen.UX402_FullScreenExercise.view.Flights
		 */
		//	onExit: function() {
		//
		//	}

	});

});