sap.ui.define([
	"student00/com/sap/training/UX402_SmartTable/test/unit/controller/Main.controller"
], function () {
	"use strict";
});