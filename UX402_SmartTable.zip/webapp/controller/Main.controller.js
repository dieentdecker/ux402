sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("student00.com.sap.training.UX402_SmartTable.controller.Main", {
		onInit: function () {

		}
	});
});